import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';

const loginSuccessAlert = document.getElementById('login-success-alert');

if (loginSuccessAlert) {
    Swal.fire({
        icon: 'success',
        title: loginSuccessAlert.dataset.title,
        text: loginSuccessAlert.dataset.message,
        confirmButtonText: 'Continue',
        confirmButtonColor: '#20b65a',
        customClass: {
            popup: 'login-success-popup',
        },
    });
}
