@extends('layouts.app')

@section('title', 'Movement Requests')
@section('page-title', 'Movement Requests')
@section('page-subtitle', 'Approve or reject pending equipment transfers')

@section('content')

<div class="card">
    <div class="card-header">
        <h2>Pending Transfer Requests</h2>
    </div>

    @if ($movements->count())
        <table>
            <thead>
                <tr>
                    <th>Equipment</th>
                    <th>Requested By</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Reason</th>
                    <th>Requested</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                @foreach ($movements as $movement)
                    <tr>
                        <td>
                            <a href="{{ route('equipment.show', $movement->equipment) }}">
                                {{ $movement->equipment?->equipment_code }}
                                -
                                {{ $movement->equipment?->name }}
                            </a>
                        </td>

                        <td>
                            {{ $movement->movedBy?->name ?? 'Unknown' }}
                        </td>

                        <td>
                            {{ $movement->fromDepartment?->name ?? 'Unassigned' }}
                            /
                            {{ $movement->fromLocation?->name ?? 'Unassigned' }}
                        </td>

                        <td>
                            {{ $movement->toDepartment?->name ?? 'Unassigned' }}
                            /
                            {{ $movement->toLocation?->name ?? 'Unassigned' }}
                        </td>

                        <td>
                            {{ $movement->reason }}

                            @if ($movement->remarks)
                                <br>
                                <small>{{ $movement->remarks }}</small>
                            @endif
                        </td>

                        <td>
                            {{ $movement->created_at?->format('M d, Y h:i A') }}
                        </td>

                        <td>
                            <div class="table-actions">

                                <form
                                    action="{{ route('movements.approve', $movement) }}"
                                    method="POST"
                                    onsubmit="return confirm('Approve this movement request?');"
                                >
                                    @csrf

                                    <button
                                        type="submit"
                                        class="btn btn-success"
                                    >
                                        Approve
                                    </button>
                                </form>

                                <form
                                    action="{{ route('movements.reject', $movement) }}"
                                    method="POST"
                                    onsubmit="return confirm('Reject this movement request?');"
                                >
                                    @csrf

                                    <input
                                        type="text"
                                        name="rejection_reason"
                                        placeholder="Reason for rejection"
                                        required
                                    >

                                    <button
                                        type="submit"
                                        class="btn btn-danger"
                                    >
                                        Reject
                                    </button>
                                </form>

                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        {{ $movements->links('pagination.app') }}
    @else
        <div class="empty-state">
            There are currently no pending movement requests.
        </div>
    @endif
</div>

@endsection