@props(['value'])

@php
    $class = match ($value) {
        'Working', 'Excellent', 'Good', 'Active', 'Approved' => 'badge-ok',
        'Under Maintenance', 'For Inspection', 'Fair', 'For Disposal', 'Pending' => 'badge-warn',
        'Not Working', 'For Repair', 'Poor', 'Damaged', 'Disposed', 'Lost', 'Rejected' => 'badge-bad',
        default => 'badge-muted',
    };
@endphp

<span {{ $attributes->merge(['class' => 'badge '.$class]) }}>{{ $value }}</span>
