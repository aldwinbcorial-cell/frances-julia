@extends('layouts.app')

@section('title', 'Import Equipment')
@section('page-title', 'Import Equipment')
@section(
    'page-subtitle',
    'Bulk import equipment records from Excel or CSV'
)

@section('content')

<div class="card">

    <h2>Upload Spreadsheet</h2>

    <div class="panel-note">
        <strong>Supported formats:</strong>
        XLSX, XLS, CSV

        <br><br>

        <strong>Required columns:</strong>

        <code>equipment_code</code>,
        <code>name</code>,
        <code>category</code>

        <br><br>

        Existing equipment codes and barcodes will not
        be imported again.
    </div>

    <form
        action="{{ route('equipment.import.store') }}"
        method="POST"
        enctype="multipart/form-data"
    >
        @csrf

        <div class="form-stack">

            <div class="form-group">

                <label for="file">
                    Excel / CSV File *
                </label>

                <input
                    type="file"
                    id="file"
                    name="file"
                    accept=".xlsx,.xls,.csv"
                    required
                >

                @error('file')
                    <div class="field-error">
                        {{ $message }}
                    </div>
                @enderror

            </div>

        </div>

        <div class="form-actions">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Import Equipment
            </button>

            <a
                href="{{ route('equipment.index') }}"
                class="btn btn-secondary"
            >
                Cancel
            </a>

        </div>

    </form>

</div>


<div class="card">

    <h2>Spreadsheet Format</h2>

    <p>
        Use the following column names in the first row
        of your spreadsheet:
    </p>

    <pre>equipment_code
barcode
name
category
brand
model
serial_number
property_number
purchase_date
purchase_price
supplier
warranty_expiry
status
condition_status
lifecycle_status
department
location
remarks</pre>

</div>

@endsection