@php
    $schedule = $maintenanceSchedule ?? null;
@endphp

<div class="panel-note">
    @if ($schedule)
        Mark this schedule completed after service. Add a maintenance record from the equipment page to capture results and cost.
    @else
        Scheduling maintenance does not change the equipment's current status or maintenance history.
    @endif
</div>

<div class="form-grid">
    @if ($schedule)
        <div class="panel-note full-width">
            <strong>Equipment:</strong>
            {{ $schedule->equipment->equipment_code }} - {{ $schedule->equipment->name }}
        </div>
    @else
        <div class="form-group full-width">
            <label for="equipment_id">Equipment *</label>
            <select id="equipment_id" name="equipment_id" required>
                <option value="">Select Equipment</option>
                @foreach ($equipmentOptions as $equipment)
                    <option value="{{ $equipment->id }}" @selected((string) old('equipment_id', $selectedEquipmentId) === (string) $equipment->id)>
                        {{ $equipment->equipment_code }} - {{ $equipment->name }}
                    </option>
                @endforeach
            </select>
            @error('equipment_id') <div class="field-error">{{ $message }}</div> @enderror
        </div>
    @endif

    <div class="form-group">
        <label for="maintenance_type">Maintenance Type *</label>
        <select id="maintenance_type" name="maintenance_type" required>
            <option value="">Select Type</option>
            @foreach (\App\Models\MaintenanceRecord::TYPES as $type)
                <option value="{{ $type }}" @selected(old('maintenance_type', $schedule?->maintenance_type) === $type)>
                    {{ $type }}
                </option>
            @endforeach
        </select>
        @error('maintenance_type') <div class="field-error">{{ $message }}</div> @enderror
    </div>

    <div class="form-group">
        <label for="scheduled_date">Scheduled Date *</label>
        <input
            type="date"
            id="scheduled_date"
            name="scheduled_date"
            value="{{ old('scheduled_date', $schedule?->scheduled_date?->format('Y-m-d')) }}"
            @if (! $schedule) min="{{ now()->toDateString() }}" @endif
            required
        >
        @error('scheduled_date') <div class="field-error">{{ $message }}</div> @enderror
    </div>

    <div class="form-group">
        <label for="assigned_to">Assigned To</label>
        <input
            type="text"
            id="assigned_to"
            name="assigned_to"
            value="{{ old('assigned_to', $schedule?->assigned_to) }}"
            placeholder="Technician or service provider"
        >
        @error('assigned_to') <div class="field-error">{{ $message }}</div> @enderror
    </div>

    @if ($schedule)
        <div class="form-group">
            <label for="status">Status *</label>
            <select id="status" name="status" required>
                @foreach (\App\Models\MaintenanceSchedule::STATUSES as $status)
                    <option value="{{ $status }}" @selected(old('status', $schedule->status) === $status)>
                        {{ $status }}
                    </option>
                @endforeach
            </select>
            @error('status') <div class="field-error">{{ $message }}</div> @enderror
        </div>
    @endif

    <div class="form-group full-width">
        <label for="description">Description *</label>
        <textarea id="description" name="description" required>{{ old('description', $schedule?->description) }}</textarea>
        @error('description') <div class="field-error">{{ $message }}</div> @enderror
    </div>

    <div class="form-group full-width">
        <label for="remarks">Remarks</label>
        <textarea id="remarks" name="remarks">{{ old('remarks', $schedule?->remarks) }}</textarea>
        @error('remarks') <div class="field-error">{{ $message }}</div> @enderror
    </div>
</div>

<div class="form-actions">
    <button type="submit" class="btn btn-primary">{{ $submitLabel }}</button>
    <a href="{{ route('maintenance-schedules.index') }}" class="btn btn-secondary">Cancel</a>
</div>
