@extends('layouts.app')

@section('title', 'Maintenance Schedule')
@section('page-title', 'Maintenance Schedule')
@section('page-subtitle', 'Plan and track equipment maintenance appointments')

@section('page-actions')
    <a href="{{ route('maintenance-schedules.create') }}" class="btn btn-primary">Schedule Maintenance</a>
@endsection

@section('content')
<div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Equipment</th>
                <th>Type</th>
                <th>Assigned To</th>
                <th>Status</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($maintenanceSchedules as $schedule)
                <tr>
                    <td>
                        @if ($schedule->status === 'Scheduled' && $schedule->scheduled_date->lt(today()))
                            <span class="text-overdue">Overdue: {{ $schedule->scheduled_date->format('M d, Y') }}</span>
                        @else
                            {{ $schedule->scheduled_date->format('M d, Y') }}
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('equipment.show', $schedule->equipment) }}">
                            {{ $schedule->equipment->equipment_code }} - {{ $schedule->equipment->name }}
                        </a>
                    </td>
                    <td>{{ $schedule->maintenance_type }}</td>
                    <td>{{ $schedule->assigned_to ?? 'N/A' }}</td>
                    <td><x-status-badge :value="$schedule->status" /></td>
                    <td>{{ $schedule->description }}</td>
                    <td>
                        <div class="table-actions">
                            <a href="{{ route('maintenance-schedules.edit', $schedule) }}" class="btn btn-secondary">Edit</a>
                            <form action="{{ route('maintenance-schedules.destroy', $schedule) }}" method="POST" onsubmit="return confirm('Delete this maintenance schedule?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="7" class="empty-state">No maintenance scheduled yet.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

{{ $maintenanceSchedules->links() }}
@endsection
