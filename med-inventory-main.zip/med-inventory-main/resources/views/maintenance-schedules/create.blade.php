@extends('layouts.app')

@section('title', 'Schedule Maintenance')
@section('page-title', 'Schedule Maintenance')
@section('page-subtitle', 'Plan a maintenance visit for equipment')

@section('content')
<div class="card">
    <form action="{{ route('maintenance-schedules.store') }}" method="POST">
        @csrf

        @include('maintenance-schedules._form', [
            'equipmentOptions' => $equipmentOptions,
            'selectedEquipmentId' => $selectedEquipmentId,
            'submitLabel' => 'Save Schedule',
        ])
    </form>
</div>
@endsection
