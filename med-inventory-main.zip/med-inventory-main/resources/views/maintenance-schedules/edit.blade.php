@extends('layouts.app')

@section('title', 'Edit Maintenance Schedule')
@section('page-title', 'Edit Maintenance Schedule')

@section('content')
<div class="card">
    <form action="{{ route('maintenance-schedules.update', $maintenanceSchedule) }}" method="POST">
        @csrf
        @method('PUT')

        @include('maintenance-schedules._form', [
            'maintenanceSchedule' => $maintenanceSchedule,
            'submitLabel' => 'Update Schedule',
        ])
    </form>
</div>
@endsection
