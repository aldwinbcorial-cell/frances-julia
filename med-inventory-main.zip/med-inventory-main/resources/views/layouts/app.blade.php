<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Dashboard') — Medical Equipment Inventory</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    @stack('styles')
</head>
<body class="app-body">
<div class="app-shell">
    <input type="checkbox" id="nav-toggle" class="nav-toggle">

    @include('partials.nav')
    <label for="nav-toggle" class="sidebar-overlay" aria-label="Close navigation"></label>

    <div class="app-main">
        <div class="app-topbar">
            <div class="app-heading-group">
                <label for="nav-toggle" class="nav-toggle-label" aria-label="Open navigation" title="Menu">
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </label>
                <div>
                    <h1>@yield('page-title')</h1>
                    @hasSection('page-subtitle')
                        <p class="page-subtitle">@yield('page-subtitle')</p>
                    @endif
                </div>
            </div>

            <div class="page-actions">
                @yield('page-actions')
            @auth
                @php
                    $unreadCount = auth()
                        ->user()
                        ->unreadNotifications()
                        ->count();
                @endphp

                <a
                    href="{{ route('notifications.index') }}"
                    class="notification-button"
                    title="Notifications"
                    aria-label="Notifications"
                >
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M18 8.5a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M10 21h4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                    </svg>

                    @if ($unreadCount > 0)
                        <span class="notification-count">
                            {{ $unreadCount > 99 ? '99+' : $unreadCount }}
                        </span>
                    @endif
                </a>

                <details class="header-user-menu">
                    <summary class="header-user-toggle" aria-label="Open account menu" title="Account">
                        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                            <circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.8"/>
                            <path d="M5 20a7 7 0 0 1 14 0" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                        </svg>
                    </summary>
                    <div class="header-user-dropdown">
                        <div class="header-user-dropdown-name">{{ auth()->user()->name }}</div>
                        <div class="header-user-dropdown-role">{{ auth()->user()->role }}</div>
                        <form action="{{ route('logout') }}" method="POST" class="header-logout-form">
                            @csrf
                            <button type="submit" class="header-logout-button">Log out</button>
                        </form>
                    </div>
                </details>
            @endauth
            </div>
        </div>

        <div class="app-content">
            @include('partials.flash')
            @yield('content')
        </div>
    </div>
</div>
@if (session('login_success'))
    <div
        id="login-success-alert"
        data-title="Log In Successfully"
        data-message="Welcome back to MIMS."
        hidden
    ></div>
    @vite('resources/js/app.js')
@endif
<script src="{{ asset('js/app.js') }}"></script>
@stack('scripts')
</body>
</html>
