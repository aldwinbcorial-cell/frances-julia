@extends('layouts.app')

@section('title', 'Notifications')
@section('page-title', 'Notifications')

@section('page-actions')
    @if (auth()->user()->unreadNotifications()->exists())
        <form
            action="{{ route('notifications.read-all') }}"
            method="POST"
        >
            @csrf

            <button
                type="submit"
                class="btn btn-secondary"
            >
                Mark All as Read
            </button>
        </form>
    @endif
@endsection

@section('content')

<div class="card">

    @if ($notifications->count())

        <div class="notification-list">

            @foreach ($notifications as $notification)

                <form action="{{ route('notifications.read', $notification->id) }}" method="POST" class="notification-form">
                    @csrf
                    <button type="submit" class="notification-item {{ $notification->read_at ? '' : 'is-unread' }}">
                        <div>
                            <strong>{{ $notification->data['title'] ?? 'Notification' }}</strong>
                            <p>{{ $notification->data['message'] ?? '' }}</p>
                            <small>{{ $notification->created_at->diffForHumans() }}</small>
                        </div>
                        @if (! $notification->read_at)
                            <span class="notification-dot"></span>
                        @endif
                    </button>
                </form>

            @endforeach

        </div>

        {{ $notifications->links('pagination.app') }}

    @else

        <div class="empty-state">
            You have no notifications.
        </div>

    @endif

</div>

@endsection 