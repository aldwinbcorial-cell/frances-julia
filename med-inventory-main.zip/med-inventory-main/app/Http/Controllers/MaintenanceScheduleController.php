<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreMaintenanceScheduleRequest;
use App\Http\Requests\UpdateMaintenanceScheduleRequest;
use App\Models\Equipment;
use App\Models\MaintenanceSchedule;
use App\Services\AuditLogger;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class MaintenanceScheduleController extends Controller
{
    public function index(): View
    {
        $maintenanceSchedules = MaintenanceSchedule::query()
            ->with('equipment')
            ->orderBy('scheduled_date')
            ->paginate(15)
            ->withQueryString();

        return view('maintenance-schedules.index', compact('maintenanceSchedules'));
    }

    public function create(Request $request): View
    {
        $equipmentOptions = Equipment::query()
            ->whereNull('archived_at')
            ->where('lifecycle_status', '!=', 'Disposed')
            ->orderBy('equipment_code')
            ->get();
        $selectedEquipmentId = old('equipment_id', $request->query('equipment_id'));

        return view('maintenance-schedules.create', compact('equipmentOptions', 'selectedEquipmentId'));
    }

    public function store(StoreMaintenanceScheduleRequest $request): RedirectResponse
    {
        $validated = $request->validated();
        $equipment = Equipment::findOrFail($validated['equipment_id']);

        if ($equipment->isDisposed() || $equipment->isArchived()) {
            return back()
                ->withInput()
                ->with('error', 'This equipment cannot be scheduled for maintenance in its current state.');
        }

        $maintenanceSchedule = MaintenanceSchedule::create($validated);

        AuditLogger::log(
            'MAINTENANCE_SCHEDULE',
            'maintenance_schedules',
            $maintenanceSchedule->id,
            null,
            $maintenanceSchedule->toArray(),
            'Scheduled maintenance for equipment: '.$equipment->equipment_code.' - '.$equipment->name
        );

        return redirect()
            ->route('maintenance-schedules.index')
            ->with('success', 'Maintenance scheduled successfully.');
    }

    public function edit(MaintenanceSchedule $maintenanceSchedule): View
    {
        $maintenanceSchedule->load('equipment');

        return view('maintenance-schedules.edit', compact('maintenanceSchedule'));
    }

    public function update(
        UpdateMaintenanceScheduleRequest $request,
        MaintenanceSchedule $maintenanceSchedule
    ): RedirectResponse {
        $oldValues = $maintenanceSchedule->toArray();
        $maintenanceSchedule->update($request->validated());
        $maintenanceSchedule->refresh();

        AuditLogger::log(
            'MAINTENANCE_SCHEDULE',
            'maintenance_schedules',
            $maintenanceSchedule->id,
            $oldValues,
            $maintenanceSchedule->toArray(),
            'Updated maintenance schedule for equipment: '.$maintenanceSchedule->equipment->equipment_code.' - '.$maintenanceSchedule->equipment->name
        );

        return redirect()
            ->route('maintenance-schedules.index')
            ->with('success', 'Maintenance schedule updated successfully.');
    }

    public function destroy(MaintenanceSchedule $maintenanceSchedule): RedirectResponse
    {
        $equipment = $maintenanceSchedule->equipment;
        $oldValues = $maintenanceSchedule->toArray();
        $maintenanceScheduleId = $maintenanceSchedule->id;
        $maintenanceSchedule->delete();

        AuditLogger::log(
            'DELETE',
            'maintenance_schedules',
            $maintenanceScheduleId,
            $oldValues,
            null,
            'Deleted maintenance schedule for equipment: '.$equipment->equipment_code.' - '.$equipment->name
        );

        return redirect()
            ->route('maintenance-schedules.index')
            ->with('success', 'Maintenance schedule deleted successfully.');
    }
}
