<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\Equipment;
use App\Models\EquipmentCategory;
use App\Models\Location;
use App\Services\AuditLogger;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class EquipmentImportController extends Controller
{
    public function create()
    {
        return view('equipment.import');
    }

    public function store(Request $request)
    {
        $request->validate([
            'file' => [
                'required',
                'file',
                'mimes:xlsx,xls,csv',
                'max:10240',
            ],
        ]);

        try {
            $spreadsheet = IOFactory::load(
                $request->file('file')->getRealPath()
            );

            $worksheet = $spreadsheet->getActiveSheet();

            $rows = $worksheet->toArray(
                null,
                true,
                true,
                false
            );

            if (count($rows) < 2) {
                return back()->with(
                    'error',
                    'The spreadsheet does not contain any equipment rows.'
                );
            }

            $headers = array_map(
                fn ($header) => strtolower(
                    trim((string) $header)
                ),
                $rows[0]
            );

            $namedHeaders = array_values(array_filter($headers, fn ($header) => $header !== ''));
            if (count($namedHeaders) !== count(array_unique($namedHeaders))) {
                return back()->with('error', 'The spreadsheet contains duplicate column headers.');
            }

            $requiredHeaders = [
                'equipment_code',
                'name',
                'category',
            ];

            foreach ($requiredHeaders as $requiredHeader) {
                if (! in_array(
                    $requiredHeader,
                    $headers,
                    true
                )) {
                    return back()->with(
                        'error',
                        "Missing required column: {$requiredHeader}"
                    );
                }
            }

            $imported = 0;
            $skipped = 0;
            $errors = [];


            foreach (
                array_slice($rows, 1) as $index => $row
            ) {
                $rowNumber = $index + 2;

                /*
                |--------------------------------------------------------------------------
                | Ignore completely empty rows
                |--------------------------------------------------------------------------
                */

                if (
                    collect($row)
                        ->filter(fn ($value) => filled($value))
                        ->isEmpty()
                ) {
                    continue;
                }

                $data = [];

                foreach ($headers as $columnIndex => $header) {
                    if ($header === '') {
                        continue;
                    }

                    $data[$header] =
                        $row[$columnIndex] ?? null;
                }

                try {
                    DB::transaction(function () use ($data, $rowNumber) {
                        $this->importRow($data, $rowNumber);
                    });

                    $imported++;

                } catch (\Throwable $e) {
                    $skipped++;

                    $errors[] =
                        "Row {$rowNumber}: "
                        .$e->getMessage();
                }
            }


            return redirect()
                ->route('equipment.index')
                ->with(
                    'success',
                    "{$imported} equipment records imported successfully. "
                    ."{$skipped} rows were skipped."
                )
                ->with(
                    'import_errors',
                    $errors
                );

        } catch (\Throwable $e) {


            return back()
                ->withInput()
                ->with(
                    'error',
                    'Import could not be processed. Check that the spreadsheet is a valid XLSX, XLS, or CSV file.'
                );
        }
    }

    private function importRow(
        array $data,
        int $rowNumber
    ): Equipment {
        $equipmentCode = trim(
            (string) ($data['equipment_code'] ?? '')
        );

        $name = trim(
            (string) ($data['name'] ?? '')
        );

        $categoryName = trim(
            (string) ($data['category'] ?? '')
        );

        if ($equipmentCode === '') {
            throw new \Exception(
                'Equipment code is required.'
            );
        }

        if ($name === '') {
            throw new \Exception(
                'Equipment name is required.'
            );
        }

        if ($categoryName === '') {
            throw new \Exception(
                'Category is required.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Prevent duplicate equipment
        |--------------------------------------------------------------------------
        */

        if (
            Equipment::where(
                'equipment_code',
                $equipmentCode
            )->exists()
        ) {
            throw new \Exception(
                "Equipment code {$equipmentCode} already exists."
            );
        }

        /*
        |--------------------------------------------------------------------------
        | CATEGORY
        |--------------------------------------------------------------------------
        |
        | Automatically create the category if it does not exist.
        |
        */

        $category =
            EquipmentCategory::firstOrCreate([
                'name' => $categoryName,
            ]);

        /*
        |--------------------------------------------------------------------------
        | DEPARTMENT
        |--------------------------------------------------------------------------
        */

        $department = null;

        $departmentName = trim(
            (string) ($data['department'] ?? '')
        );

        if ($departmentName !== '') {
            $department =
                Department::firstOrCreate([
                    'name' => $departmentName,
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | LOCATION
        |--------------------------------------------------------------------------
        */

        $location = null;

        $locationName = trim(
            (string) ($data['location'] ?? '')
        );

        if ($locationName !== '') {

            if (! $department) {
                throw new \Exception(
                    'A department is required when a location is specified.'
                );
            }

            $location =
                Location::firstOrCreate([
                    'department_id' => $department->id,
                    'name' => $locationName,
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Barcode duplicate protection
        |--------------------------------------------------------------------------
        */

        $barcode = $this->nullableString(
            $data['barcode'] ?? null
        );

        if (
            $barcode
            && Equipment::where(
                'barcode',
                $barcode
            )->exists()
        ) {
            throw new \Exception(
                "Barcode {$barcode} already exists."
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Validate statuses
        |--------------------------------------------------------------------------
        */

        $status =
            $this->nullableString(
                $data['status'] ?? null
            )
            ?? 'Working';

        if (
            ! in_array(
                $status,
                Equipment::OPERATIONAL_STATUSES,
                true
            )
        ) {
            throw new \Exception(
                "Invalid operational status: {$status}"
            );
        }

        $condition =
            $this->nullableString(
                $data['condition_status'] ?? null
            )
            ?? 'Good';

        if (
            ! in_array(
                $condition,
                Equipment::CONDITIONS,
                true
            )
        ) {
            throw new \Exception(
                "Invalid condition: {$condition}"
            );
        }

        $lifecycleStatus =
            $this->nullableString(
                $data['lifecycle_status'] ?? null
            )
            ?? 'Active';

        if (
            ! in_array(
                $lifecycleStatus,
                Equipment::EDITABLE_LIFECYCLE_STATUSES,
                true
            )
        ) {
            throw new \Exception(
                "Invalid lifecycle status: {$lifecycleStatus}"
            );
        }

        $equipment = Equipment::create([
            'equipment_code' => $equipmentCode,

            'barcode' => $barcode,

            'name' => $name,

            'category_id' => $category->id,

            'brand' =>
                $this->nullableString(
                    $data['brand'] ?? null
                ),

            'model' =>
                $this->nullableString(
                    $data['model'] ?? null
                ),

            'serial_number' =>
                $this->nullableString(
                    $data['serial_number'] ?? null
                ),

            'property_number' =>
                $this->nullableString(
                    $data['property_number'] ?? null
                ),

            'purchase_date' =>
                $this->parseDate(
                    $data['purchase_date'] ?? null
                ),

            'purchase_price' =>
                $this->nullableNumber(
                    $data['purchase_price'] ?? null
                ),

            'supplier' =>
                $this->nullableString(
                    $data['supplier'] ?? null
                ),

            'warranty_expiry' =>
                $this->parseDate(
                    $data['warranty_expiry'] ?? null
                ),

            'status' => $status,

            'condition_status' => $condition,

            'lifecycle_status' => $lifecycleStatus,

            'department_id' => $department?->id,

            'location_id' => $location?->id,

            'remarks' =>
                $this->nullableString(
                    $data['remarks'] ?? null
                ),
        ]);

        AuditLogger::log(
            'IMPORT',
            'equipment',
            $equipment->id,
            null,
            $equipment->toArray(),
            "Imported equipment from spreadsheet: "
            .$equipment->equipment_code
            .' - '
            .$equipment->name
        );

        return $equipment;
    }

    private function nullableString(
        mixed $value
    ): ?string {
        if (
            $value === null
            || trim((string) $value) === ''
        ) {
            return null;
        }

        return trim((string) $value);
    }

    private function nullableNumber(
        mixed $value
    ): ?float {
        if (
            $value === null
            || $value === ''
        ) {
            return null;
        }

        if (! is_numeric($value)) {
            throw new \Exception(
                "Invalid numeric value: {$value}"
            );
        }

        return (float) $value;
    }

    private function parseDate(
        mixed $value
    ): ?string {
        if (
            $value === null
            || $value === ''
        ) {
            return null;
        }

        /*
        |--------------------------------------------------------------------------
        | Real Excel date number
        |--------------------------------------------------------------------------
        */

        if (is_numeric($value)) {
            return Date::excelToDateTimeObject(
                $value
            )->format('Y-m-d');
        }

        /*
        |--------------------------------------------------------------------------
        | Normal text date
        |--------------------------------------------------------------------------
        */

        $timestamp = strtotime(
            (string) $value
        );

        if ($timestamp === false) {
            throw new \Exception(
                "Invalid date: {$value}"
            );
        }

        return date(
            'Y-m-d',
            $timestamp
        );
    }
}