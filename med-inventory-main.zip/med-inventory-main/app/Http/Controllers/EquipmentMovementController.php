<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreEquipmentMovementRequest;
use App\Models\Department;
use App\Models\Equipment;
use App\Models\EquipmentMovement;
use App\Models\Location;
use App\Models\User;
use App\Notifications\MovementApprovalRequested;
use App\Notifications\MovementRequestApproved;
use App\Notifications\MovementRequestRejected;
use App\Services\AuditLogger;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Log;

class EquipmentMovementController extends Controller
{
    public function index()
    {
        abort_unless(auth()->user()->canManageInventory(), 403);

        $movements = EquipmentMovement::query()
            ->with(['equipment', 'fromDepartment', 'fromLocation', 'toDepartment', 'toLocation', 'movedBy'])
            ->where('approval_status', 'Pending')
            ->latest()
            ->paginate(15);

        return view('movements.index', compact('movements'));
    }

    public function create(Equipment $equipment)
    {
        if ($equipment->isDisposed() || $equipment->isArchived()) {
            return redirect()->route('equipment.show', $equipment)
                ->with('error', 'This equipment cannot be moved in its current state.');
        }

        return view('movements.create', [
            'equipment' => $equipment,
            'departments' => Department::orderBy('name')->get(),
            'locations' => Location::with('department')->orderBy('name')->get(),
        ]);
    }

    public function store(StoreEquipmentMovementRequest $request, Equipment $equipment)
    {
        $validated = $request->validated();
        $user = $request->user();

        // Lock equipment while capturing the original assignment. This protects
        // against a simultaneous direct movement changing the source location.
        $result = DB::transaction(function () use ($equipment, $validated, $user) {
            $equipment = Equipment::query()->lockForUpdate()->findOrFail($equipment->id);

            if ($equipment->isDisposed() || $equipment->isArchived()) {
                return ['error' => 'This equipment cannot be moved in its current state.'];
            }

            if ((int) $equipment->department_id === (int) $validated['department_id']
                && (int) $equipment->location_id === (int) $validated['location_id']) {
                return ['error' => 'Equipment is already assigned to that location.'];
            }

            $direct = $user->canManageInventory();
            $movement = EquipmentMovement::create([
                'equipment_id' => $equipment->id,
                'from_department_id' => $equipment->department_id,
                'from_location_id' => $equipment->location_id,
                'to_department_id' => $validated['department_id'],
                'to_location_id' => $validated['location_id'],
                'movement_date' => now(),
                'reason' => $validated['reason'],
                'remarks' => $validated['remarks'] ?? null,
                'moved_by' => $user->id,
                'approval_status' => $direct ? 'Approved' : 'Pending',
                'approved_by' => $direct ? $user->id : null,
                'approved_at' => $direct ? now() : null,
            ]);

            if ($direct) {
                $before = $equipment->toArray();
                $equipment->update([
                    'department_id' => $validated['department_id'],
                    'location_id' => $validated['location_id'],
                ]);
                AuditLogger::log('MOVE', 'equipment_movements', $movement->id,
                    $before, $equipment->fresh()->toArray(),
                    'Moved equipment: '.$equipment->equipment_code.' - '.$equipment->name.'. Reason: '.$validated['reason']);
            } else {
                AuditLogger::log('MOVEMENT_REQUEST', 'equipment_movements', $movement->id,
                    null, $movement->toArray(),
                    'Requested movement of equipment: '.$equipment->equipment_code.' - '.$equipment->name);
            }

            return ['movement' => $movement];
        });

        if (isset($result['error'])) {
            return redirect()->route('equipment.show', $equipment)->with('error', $result['error']);
        }

        $movement = $result['movement'];
        if ($movement->approval_status === 'Pending') {
            // Send only after the transaction has successfully committed.
            $movement->load(['equipment', 'movedBy']);
            $approvers = User::whereIn('role', [User::ROLE_ADMINISTRATOR, User::ROLE_INVENTORY_OFFICER])->get();
            try {
                Notification::send($approvers, new MovementApprovalRequested($movement));
            } catch (\Throwable $exception) {
                Log::error('Movement request notification failed', [
                    'movement_id' => $movement->id,
                    'exception' => $exception,
                ]);
            }

            return redirect()->route('equipment.show', $equipment)
                ->with('success', 'Movement request submitted. An Inventory Officer or Administrator must approve it before the asset is transferred.');
        }

        return redirect()->route('equipment.show', $equipment)->with('success', 'Equipment moved successfully.');
    }

    public function approve(EquipmentMovement $movement)
    {
        abort_unless(auth()->user()->canManageInventory(), 403);

        $result = DB::transaction(function () use ($movement) {
            // Always lock and re-read the movement before deciding its state.
            $movement = EquipmentMovement::query()->lockForUpdate()->findOrFail($movement->id);
            if ($movement->approval_status !== 'Pending') {
                return ['error' => 'This movement request has already been processed.'];
            }

            $equipment = Equipment::query()->lockForUpdate()->find($movement->equipment_id);
            if (! $equipment || $equipment->isDisposed() || $equipment->isArchived()) {
                return ['error' => 'This equipment can no longer be moved.'];
            }

            // A later movement must never be silently overwritten by an old request.
            if ((string) $equipment->department_id !== (string) $movement->from_department_id
                || (string) $equipment->location_id !== (string) $movement->from_location_id) {
                return ['error' => 'The asset assignment has changed since this request was made. Reject the outdated request and submit a new one.'];
            }

            $before = $equipment->toArray();
            $equipment->update([
                'department_id' => $movement->to_department_id,
                'location_id' => $movement->to_location_id,
            ]);
            $movement->update([
                'approval_status' => 'Approved',
                'approved_by' => auth()->id(),
                'approved_at' => now(),
                'rejection_reason' => null,
            ]);

            AuditLogger::log('APPROVE_MOVEMENT', 'equipment_movements', $movement->id,
                $before, $equipment->fresh()->toArray(),
                'Approved movement request for equipment: '.$equipment->equipment_code.' - '.$equipment->name);

            return ['movement' => $movement];
        });

        if (isset($result['error'])) {
            return back()->with('error', $result['error']);
        }

        $movement = $result['movement']->load(['equipment', 'movedBy']);
        try {
            $movement->movedBy?->notify(new MovementRequestApproved($movement));
        } catch (\Throwable $exception) {
            Log::error('Movement approval notification failed', [
                'movement_id' => $movement->id,
                'exception' => $exception,
            ]);
        }

        return back()->with('success', 'Movement request approved. The equipment assignment has been updated.');
    }

    public function reject(Request $request, EquipmentMovement $movement)
    {
        abort_unless($request->user()->canManageInventory(), 403);
        $validated = $request->validate(['rejection_reason' => ['required', 'string', 'max:1000']]);

        $result = DB::transaction(function () use ($movement, $validated) {
            $movement = EquipmentMovement::query()->lockForUpdate()->findOrFail($movement->id);
            if ($movement->approval_status !== 'Pending') {
                return ['error' => 'This movement request has already been processed.'];
            }

            $movement->update([
                'approval_status' => 'Rejected',
                'approved_by' => auth()->id(),
                'approved_at' => now(),
                'rejection_reason' => $validated['rejection_reason'],
            ]);
            AuditLogger::log('REJECT_MOVEMENT', 'equipment_movements', $movement->id,
                null, $movement->toArray(), 'Rejected equipment movement request.');

            return ['movement' => $movement];
        });

        if (isset($result['error'])) {
            return back()->with('error', $result['error']);
        }

        $movement = $result['movement']->load(['equipment', 'movedBy']);
        try {
            $movement->movedBy?->notify(new MovementRequestRejected($movement));
        } catch (\Throwable $exception) {
            Log::error('Movement rejection notification failed', [
                'movement_id' => $movement->id,
                'exception' => $exception,
            ]);
        }

        return back()->with('success', 'Movement request rejected.');
    }
}
