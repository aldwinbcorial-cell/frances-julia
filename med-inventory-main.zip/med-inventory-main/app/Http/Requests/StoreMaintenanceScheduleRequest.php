<?php

namespace App\Http\Requests;

use App\Models\Equipment;
use App\Models\MaintenanceRecord;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreMaintenanceScheduleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->canMaintainEquipment() === true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'equipment_id' => ['required', 'integer', Rule::exists(Equipment::class, 'id')],
            'maintenance_type' => ['required', 'string', Rule::in(MaintenanceRecord::TYPES)],
            'scheduled_date' => ['required', 'date', 'after_or_equal:today'],
            'assigned_to' => ['nullable', 'string', 'max:255'],
            'description' => ['required', 'string'],
            'remarks' => ['nullable', 'string'],
        ];
    }
}
