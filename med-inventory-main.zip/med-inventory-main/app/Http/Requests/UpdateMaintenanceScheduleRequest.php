<?php

namespace App\Http\Requests;

use App\Models\MaintenanceRecord;
use App\Models\MaintenanceSchedule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateMaintenanceScheduleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->canMaintainEquipment() === true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'maintenance_type' => ['required', 'string', Rule::in(MaintenanceRecord::TYPES)],
            'scheduled_date' => [
                'required',
                'date',
                Rule::when($this->input('status') === 'Scheduled', ['after_or_equal:today']),
            ],
            'assigned_to' => ['nullable', 'string', 'max:255'],
            'description' => ['required', 'string'],
            'status' => ['required', Rule::in(MaintenanceSchedule::STATUSES)],
            'remarks' => ['nullable', 'string'],
        ];
    }
}
