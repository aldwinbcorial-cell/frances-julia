<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EquipmentMovement extends Model
{
    use HasFactory;

    protected $fillable = [
    'equipment_id',
    'from_department_id',
    'from_location_id',
    'to_department_id',
    'to_location_id',
    'movement_date',
    'reason',
    'remarks',
    'moved_by',
    'approval_status',
    'approved_by',
    'approved_at',
    'rejection_reason',
    ];

    protected $casts = [
    'movement_date' => 'datetime',
    'approved_at' => 'datetime',
    ];

    public function equipment()
    {
        return $this->belongsTo(Equipment::class);
    }

    public function fromDepartment()
    {
        return $this->belongsTo(Department::class, 'from_department_id');
    }

    public function toDepartment()
    {
        return $this->belongsTo(Department::class, 'to_department_id');
    }

    public function fromLocation()
    {
        return $this->belongsTo(Location::class, 'from_location_id');
    }

    public function toLocation()
    {
        return $this->belongsTo(Location::class, 'to_location_id');
    }

    public function movedBy()
    {
        return $this->belongsTo(User::class, 'moved_by');
    }

    public function approvedBy()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function isPending(): bool
    {
        return $this->approval_status === 'Pending';
    }

    public function isApproved(): bool
    {
        return $this->approval_status === 'Approved';
    }

    public function isRejected(): bool
    {
        return $this->approval_status === 'Rejected';
    }
}