<?php

namespace App\Models;

use Database\Factories\MaintenanceScheduleFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MaintenanceSchedule extends Model
{
    /** @use HasFactory<MaintenanceScheduleFactory> */
    use HasFactory;

    public const STATUSES = [
        'Scheduled',
        'Completed',
        'Cancelled',
    ];

    protected $fillable = [
        'equipment_id',
        'maintenance_type',
        'scheduled_date',
        'assigned_to',
        'description',
        'status',
        'remarks',
    ];

    protected $casts = [
        'scheduled_date' => 'date',
    ];

    public function equipment(): BelongsTo
    {
        return $this->belongsTo(Equipment::class);
    }
}
