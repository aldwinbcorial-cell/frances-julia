<?php

namespace App\Notifications;

use App\Models\EquipmentMovement;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class MovementRequestRejected extends Notification
{
    use Queueable;

    public function __construct(
        public EquipmentMovement $movement
    ) {
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        $equipment = $this->movement->equipment;

        return [
            'title' => 'Transfer Request Rejected',

            'message' =>
                'Your transfer request for '
                .($equipment?->equipment_code ?? 'equipment')
                .' was rejected. Reason: '
                .($this->movement->rejection_reason ?? 'No reason provided.'),

            'movement_id' => $this->movement->id,

            'equipment_id' => $equipment?->id,

            'url' => $equipment
                ? route('equipment.show', $equipment)
                : route('equipment.index'),

            'level' => 'danger',
        ];
    }
}