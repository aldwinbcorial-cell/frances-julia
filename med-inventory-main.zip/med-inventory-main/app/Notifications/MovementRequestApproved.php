<?php

namespace App\Notifications;

use App\Models\EquipmentMovement;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class MovementRequestApproved extends Notification
{
    use Queueable;

    public function __construct(
        public EquipmentMovement $movement
    ) {
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        $equipment = $this->movement->equipment;

        return [
            'title' => 'Transfer Request Approved',

            'message' =>
                'Your transfer request for '
                .($equipment?->equipment_code ?? 'equipment')
                .' - '
                .($equipment?->name ?? '')
                .' has been approved.',

            'movement_id' => $this->movement->id,

            'equipment_id' => $equipment?->id,

            'url' => $equipment
                ? route('equipment.show', $equipment)
                : route('equipment.index'),

            'level' => 'success',
        ];
    }
}