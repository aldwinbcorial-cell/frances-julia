<?php

namespace App\Notifications;

use App\Models\EquipmentMovement;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class MovementApprovalRequested extends Notification
{
    use Queueable;

    public function __construct(
        public EquipmentMovement $movement
    ) {
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        $equipment = $this->movement->equipment;

        return [
            'title' => 'Movement Approval Required',

            'message' =>
                ($this->movement->movedBy?->name ?? 'A user')
                .' requested to transfer '
                .($equipment?->equipment_code ?? 'equipment')
                .' - '
                .($equipment?->name ?? ''),

            'movement_id' => $this->movement->id,

            'equipment_id' => $equipment?->id,

            'url' => route('movements.index'),

            'level' => 'warning',
        ];
    }
}