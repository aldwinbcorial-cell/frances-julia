<?php $__env->startSection('title', $equipment->name); ?>
<?php $__env->startSection('page-title', $equipment->name); ?>
<?php $__env->startSection('page-subtitle', $equipment->equipment_code); ?>

<?php $__env->startSection('page-actions'); ?>
    <?php $user = auth()->user(); ?>

    <?php if($equipment->isArchived() && $user->canManageInventory()): ?>
        <form action="<?php echo e(route('equipment.restore', $equipment)); ?>" method="POST" onsubmit="return confirm('Restore this equipment?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <button type="submit" class="btn btn-success">Restore</button>
        </form>
    <?php endif; ?>

    <?php if(
        ! $equipment->isDisposed()
        && ! $equipment->isArchived()
        && in_array($user->role, [
            'Administrator',
            'Inventory Officer',
            'Maintenance Staff',
            'Department Staff'
        ])
    ): ?>
        <a
            href="<?php echo e(route('equipment.move', $equipment)); ?>"
            class="btn btn-primary"
        >
            <?php echo e($user->canManageInventory() ? 'Move Equipment' : 'Request Transfer'); ?>

        </a>
    <?php endif; ?>

    <?php if(
        ! $equipment->isDisposed()
        && ! $equipment->isArchived()
        && $user->canMaintainEquipment()
    ): ?>
        <a
            href="<?php echo e(route('maintenance-schedules.create', ['equipment_id' => $equipment->id])); ?>"
            class="btn btn-primary"
        >
            Schedule Maintenance
        </a>
    <?php endif; ?>

    <?php if(
        ! $equipment->isDisposed()
        && ! $equipment->isArchived()
        && $user->canManageInventory()
    ): ?>
        <a
            href="<?php echo e(route('equipment.edit', $equipment)); ?>"
            class="btn btn-secondary"
        >
            Edit
        </a>
    <?php endif; ?>

    <a href="<?php echo e(route('equipment.index')); ?>" class="btn btn-secondary">Back</a>

    <?php if(! $equipment->isArchived() && $user->canManageInventory()): ?>
        <form action="<?php echo e(route('equipment.destroy', $equipment)); ?>" method="POST" onsubmit="return confirm('Archive this equipment?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Archive</button>
        </form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if($equipment->isArchived()): ?>
    <div class="alert alert-info">This equipment is archived and excluded from the active inventory.</div>
<?php endif; ?>

<div class="card">
    <h2>Equipment Information</h2>
    <div class="details-grid">
        <div class="detail-item">
            <div class="detail-label">Equipment Code</div>
            <div class="detail-value"><?php echo e($equipment->equipment_code); ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Barcode</div>
            <div class="detail-value"><?php echo e($equipment->barcode ?? 'N/A'); ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Category</div>
            <div class="detail-value"><?php echo e($equipment->category?->name ?? 'N/A'); ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Brand</div>
            <div class="detail-value"><?php echo e($equipment->brand ?? 'N/A'); ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Model</div>
            <div class="detail-value"><?php echo e($equipment->model ?? 'N/A'); ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Serial Number</div>
            <div class="detail-value"><?php echo e($equipment->serial_number ?? 'N/A'); ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Property Number</div>
            <div class="detail-value"><?php echo e($equipment->property_number ?? 'N/A'); ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Supplier</div>
            <div class="detail-value"><?php echo e($equipment->supplier ?? 'N/A'); ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Purchase Date</div>
            <div class="detail-value"><?php echo e($equipment->purchase_date?->format('M d, Y') ?? 'N/A'); ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Purchase Price</div>
            <div class="detail-value">
                <?php if($equipment->purchase_price): ?>
                    ₱<?php echo e(number_format((float) $equipment->purchase_price, 2)); ?>

                <?php else: ?>
                    N/A
                <?php endif; ?>
            </div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Warranty Expiry</div>
            <div class="detail-value"><?php echo e($equipment->warranty_expiry?->format('M d, Y') ?? 'N/A'); ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Department</div>
            <div class="detail-value"><?php echo e($equipment->department?->name ?? 'Unassigned'); ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Location</div>
            <div class="detail-value"><?php echo e($equipment->location?->name ?? 'Unassigned'); ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Operational Status</div>
            <div class="detail-value"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['value' => $equipment->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($equipment->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Condition</div>
            <div class="detail-value"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['value' => $equipment->condition_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($equipment->condition_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></div>
        </div>
        <div class="detail-item">
            <div class="detail-label">Lifecycle Status</div>
            <div class="detail-value"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['value' => $equipment->lifecycle_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($equipment->lifecycle_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></div>
        </div>
        <div class="detail-item full-width">
            <div class="detail-label">Remarks</div>
            <div class="detail-value"><?php echo e($equipment->remarks ?? 'No remarks.'); ?></div>
        </div>
    </div>
</div>

<div class="card">
    <h2>Maintenance Schedule</h2>

    <?php if($equipment->maintenanceSchedules->count()): ?>
        <table>
            <thead>
                <tr>
                    <th>Scheduled Date</th>
                    <th>Type</th>
                    <th>Assigned To</th>
                    <th>Status</th>
                    <th>Description</th>
                    <?php if(auth()->user()->canMaintainEquipment()): ?>
                        <th>Actions</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $equipment->maintenanceSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if($schedule->status === 'Scheduled' && $schedule->scheduled_date->lt(today())): ?>
                                <span class="text-overdue">Overdue: <?php echo e($schedule->scheduled_date->format('M d, Y')); ?></span>
                            <?php else: ?>
                                <?php echo e($schedule->scheduled_date->format('M d, Y')); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($schedule->maintenance_type); ?></td>
                        <td><?php echo e($schedule->assigned_to ?? 'N/A'); ?></td>
                        <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['value' => $schedule->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($schedule->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                        <td><?php echo e($schedule->description); ?></td>
                        <?php if(auth()->user()->canMaintainEquipment()): ?>
                            <td>
                                <div class="table-actions">
                                    <a href="<?php echo e(route('maintenance-schedules.edit', $schedule)); ?>" class="btn btn-secondary">Edit</a>
                                    <form action="<?php echo e(route('maintenance-schedules.destroy', $schedule)); ?>" method="POST" onsubmit="return confirm('Delete this maintenance schedule?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="empty-state">No maintenance scheduled.</div>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Movement History</h2>
    <?php if($equipment->movements->count()): ?>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Reason</th>
                    <th>Requested By</th>
                    <th>Status</th>
                    <th>Approved By</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $equipment->movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($movement->movement_date?->format('M d, Y h:i A')); ?>

                        </td>

                        <td>
                            <?php echo e($movement->fromDepartment?->name ?? 'N/A'); ?>

                            /
                            <?php echo e($movement->fromLocation?->name ?? 'N/A'); ?>

                        </td>

                        <td>
                            <?php echo e($movement->toDepartment?->name ?? 'N/A'); ?>

                            /
                            <?php echo e($movement->toLocation?->name ?? 'N/A'); ?>

                        </td>

                        <td>
                            <?php echo e($movement->reason); ?>

                        </td>

                        <td>
                            <?php echo e($movement->movedBy?->name ?? 'N/A'); ?>

                        </td>

                        <td>
                            <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['value' => $movement->approval_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movement->approval_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                        </td>

                        <td>
                            <?php echo e($movement->approvedBy?->name ?? 'Pending'); ?>


                            <?php if($movement->approval_status === 'Rejected'): ?>
                                <br>
                                <small>
                                    <?php echo e($movement->rejection_reason); ?>

                                </small>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="empty-state">No movement history yet.</div>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-header">
        <h2>Maintenance History</h2>
        <?php if(! $equipment->isDisposed() && ! $equipment->isArchived() && auth()->user()->canMaintainEquipment()): ?>
            <a href="<?php echo e(route('maintenance.create', $equipment)); ?>" class="btn btn-primary">Add Maintenance</a>
        <?php endif; ?>
    </div>

    <?php
        $nextMaintenance = $equipment->maintenanceRecords
            ->whereNotNull('next_maintenance_date')
            ->sortBy('next_maintenance_date')
            ->first();
        $nextDate = $nextMaintenance?->next_maintenance_date;
    ?>

    <?php if($nextDate): ?>
        <?php if($nextDate->isPast()): ?>
            <div class="alert alert-error">
                <strong>Maintenance Overdue:</strong>
                This equipment was scheduled for maintenance on <?php echo e($nextDate->format('M d, Y')); ?>.
            </div>
        <?php elseif($nextDate->lte(now()->addDays(30))): ?>
            <div class="alert alert-warning">
                <strong>Upcoming Maintenance:</strong>
                This equipment is scheduled for maintenance on <?php echo e($nextDate->format('M d, Y')); ?>.
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if($equipment->maintenanceRecords->count()): ?>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Type</th>
                    <th>Performed By</th>
                    <th>Result</th>
                    <th>Cost</th>
                    <?php if(auth()->user()->canMaintainEquipment()): ?>
                        <th>Actions</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $equipment->maintenanceRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($record->maintenance_date?->format('M d, Y')); ?></td>
                        <td><?php echo e($record->maintenance_type); ?></td>
                        <td><?php echo e($record->performed_by ?? 'N/A'); ?></td>
                        <td><?php echo e($record->result ?? 'N/A'); ?></td>
                        <td>
                            <?php if($record->cost): ?>
                                ₱<?php echo e(number_format((float) $record->cost, 2)); ?>

                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <?php if(auth()->user()->canMaintainEquipment()): ?>
                            <td>
                                <?php if(! $equipment->isDisposed() && ! $equipment->isArchived()): ?>
                                    <div class="table-actions">
                                        <a href="<?php echo e(route('maintenance.edit', $record)); ?>" class="btn btn-secondary">Edit</a>
                                        <form action="<?php echo e(route('maintenance.destroy', $record)); ?>" method="POST" onsubmit="return confirm('Delete this maintenance record?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </div>
                                <?php else: ?>
                                    <span class="muted">History locked</span>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="empty-state">No maintenance history yet.</div>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-header">
        <h2>Disposal Information</h2>
        <?php if(! $equipment->disposalRecord && $equipment->lifecycle_status === 'For Disposal' && ! $equipment->isArchived() && auth()->user()->canManageInventory()): ?>
            <a href="<?php echo e(route('disposal.create', $equipment)); ?>" class="btn btn-danger">Dispose Equipment</a>
        <?php endif; ?>
    </div>

    <?php if($equipment->disposalRecord): ?>
        <div class="details-grid">
            <div class="detail-item">
                <div class="detail-label">Disposal Date</div>
                <div class="detail-value"><?php echo e($equipment->disposalRecord->disposal_date?->format('M d, Y')); ?></div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Method</div>
                <div class="detail-value"><?php echo e($equipment->disposalRecord->disposal_method ?? 'N/A'); ?></div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Reference</div>
                <div class="detail-value"><?php echo e($equipment->disposalRecord->disposal_reference ?? 'N/A'); ?></div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Approved By</div>
                <div class="detail-value"><?php echo e($equipment->disposalRecord->approvedBy?->name ?? 'Not recorded'); ?></div>
            </div>
            <div class="detail-item full-width">
                <div class="detail-label">Reason</div>
                <div class="detail-value"><?php echo e($equipment->disposalRecord->reason); ?></div>
            </div>
            <div class="detail-item full-width">
                <div class="detail-label">Remarks</div>
                <div class="detail-value"><?php echo e($equipment->disposalRecord->remarks ?? 'No remarks.'); ?></div>
            </div>
        </div>

        <?php if(auth()->user()->canManageInventory() && ! $equipment->isArchived()): ?>
            <div class="form-actions">
                <a href="<?php echo e(route('disposal.edit', $equipment->disposalRecord)); ?>" class="btn btn-secondary">Edit Disposal Record</a>
                <form action="<?php echo e(route('disposal.destroy', $equipment->disposalRecord)); ?>" method="POST" onsubmit="return confirm('Remove this disposal record?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Remove Disposal Record</button>
                </form>
            </div>
        <?php elseif($equipment->isArchived() && auth()->user()->canManageInventory()): ?>
            <p class="muted">Restore this equipment before changing its disposal record.</p>
        <?php endif; ?>
    <?php else: ?>
        <div class="empty-state">No disposal record.</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/equipment/show.blade.php ENDPATH**/ ?>