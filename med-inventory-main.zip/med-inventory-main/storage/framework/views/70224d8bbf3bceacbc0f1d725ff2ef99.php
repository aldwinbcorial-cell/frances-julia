<?php $__env->startSection('title', 'Departments'); ?>
<?php $__env->startSection('page-title', 'Departments'); ?>

<?php $__env->startSection('page-actions'); ?>
    <?php if(auth()->user()->canManageInventory()): ?>
        <a href="<?php echo e(route('departments.create')); ?>" class="btn btn-primary">Add Department</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Locations</th>
                <th>Equipment</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($department->name); ?></td>
                    <td><?php echo e($department->description ?? 'N/A'); ?></td>
                    <td><?php echo e($department->locations_count); ?></td>
                    <td><?php echo e($department->equipment_count); ?></td>
                    <td>
                        <div class="table-actions">
                            <a href="<?php echo e(route('departments.show', $department)); ?>" class="btn btn-secondary">View</a>
                            <?php if(auth()->user()->canManageInventory()): ?>
                                <a href="<?php echo e(route('departments.edit', $department)); ?>" class="btn btn-secondary">Edit</a>
                                <?php if($department->locations_count === 0 && $department->equipment_count === 0): ?>
                                    <form action="<?php echo e(route('departments.destroy', $department)); ?>" method="POST" onsubmit="return confirm('Delete this department?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="empty-state">No departments found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php echo e($departments->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/departments/index.blade.php ENDPATH**/ ?>