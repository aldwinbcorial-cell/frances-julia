

<?php $__env->startSection('title', 'Maintenance Schedule'); ?>
<?php $__env->startSection('page-title', 'Maintenance Schedule'); ?>
<?php $__env->startSection('page-subtitle', 'Plan and track equipment maintenance appointments'); ?>

<?php $__env->startSection('page-actions'); ?>
    <a href="<?php echo e(route('maintenance-schedules.create')); ?>" class="btn btn-primary">Schedule Maintenance</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Equipment</th>
                <th>Type</th>
                <th>Assigned To</th>
                <th>Status</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $maintenanceSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if($schedule->status === 'Scheduled' && $schedule->scheduled_date->lt(today())): ?>
                            <span class="text-overdue">Overdue: <?php echo e($schedule->scheduled_date->format('M d, Y')); ?></span>
                        <?php else: ?>
                            <?php echo e($schedule->scheduled_date->format('M d, Y')); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('equipment.show', $schedule->equipment)); ?>">
                            <?php echo e($schedule->equipment->equipment_code); ?> - <?php echo e($schedule->equipment->name); ?>

                        </a>
                    </td>
                    <td><?php echo e($schedule->maintenance_type); ?></td>
                    <td><?php echo e($schedule->assigned_to ?? 'N/A'); ?></td>
                    <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['value' => $schedule->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($schedule->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                    <td><?php echo e($schedule->description); ?></td>
                    <td>
                        <div class="table-actions">
                            <a href="<?php echo e(route('maintenance-schedules.edit', $schedule)); ?>" class="btn btn-secondary">Edit</a>
                            <form action="<?php echo e(route('maintenance-schedules.destroy', $schedule)); ?>" method="POST" onsubmit="return confirm('Delete this maintenance schedule?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="empty-state">No maintenance scheduled yet.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php echo e($maintenanceSchedules->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/maintenance-schedules/index.blade.php ENDPATH**/ ?>