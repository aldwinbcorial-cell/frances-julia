<?php $__env->startSection('title', 'Equipment Categories'); ?>
<?php $__env->startSection('page-title', 'Equipment Categories'); ?>
<?php $__env->startSection('page-subtitle', 'Manage categories used for equipment records'); ?>

<?php $__env->startSection('page-actions'); ?>
    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">Add Category</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Equipment Count</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($category->name); ?></td>
                    <td><?php echo e($category->description ?? 'N/A'); ?></td>
                    <td><?php echo e($category->equipment_count); ?></td>
                    <td>
                        <div class="table-actions">
                            <a href="<?php echo e(route('categories.edit', $category)); ?>" class="btn btn-secondary">Edit</a>
                            <?php if($category->equipment_count === 0): ?>
                                <form
                                    action="<?php echo e(route('categories.destroy', $category)); ?>"
                                    method="POST"
                                    onsubmit="return confirm('Delete this category?');"
                                >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="empty-state">No categories found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php echo e($categories->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/categories/index.blade.php ENDPATH**/ ?>