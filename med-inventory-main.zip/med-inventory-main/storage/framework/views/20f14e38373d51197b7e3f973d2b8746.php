<?php
    $user = auth()->user();
?>

<aside class="sidebar">
    <div class="sidebar-brand">
        <strong>Medical Inventory</strong>
        <span>Equipment &amp; asset tracking</span>
    </div>

    <nav class="sidebar-nav">
        <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'is-active' : ''); ?>">
            Dashboard
        </a>

        <div class="nav-section">Inventory</div>

        <a href="<?php echo e(route('equipment.index')); ?>" class="<?php echo e(request()->routeIs('equipment.index', 'equipment.show', 'equipment.edit', 'equipment.scan') ? 'is-active' : ''); ?>">
            Equipment
        </a>

        <?php if($user->canManageInventory()): ?>
            <a href="<?php echo e(route('equipment.create')); ?>" class="<?php echo e(request()->routeIs('equipment.create') ? 'is-active' : ''); ?>">
                Add Equipment
            </a>

            <a
                href="<?php echo e(route('equipment.import')); ?>"
                class="<?php echo e(request()->routeIs('equipment.import*') ? 'is-active' : ''); ?>"
            >
                Import Equipment
            </a>

            <a href="<?php echo e(route('equipment.archived')); ?>" class="<?php echo e(request()->routeIs('equipment.archived') ? 'is-active' : ''); ?>">
                Archived Equipment
            </a>

            <a href="<?php echo e(route('categories.index')); ?>" class="<?php echo e(request()->routeIs('categories.*') ? 'is-active' : ''); ?>">
                Categories
            </a>
        <?php endif; ?>

        <div class="nav-section">Organization</div>

        <a href="<?php echo e(route('departments.index')); ?>" class="<?php echo e(request()->routeIs('departments.*') ? 'is-active' : ''); ?>">
            Departments
        </a>

        <a href="<?php echo e(route('locations.index')); ?>" class="<?php echo e(request()->routeIs('locations.*') ? 'is-active' : ''); ?>">
            Locations
        </a>

        <?php if($user->canMaintainEquipment()): ?>
            <div class="nav-section">Operations</div>
        <?php endif; ?>

        <?php if($user->canMaintainEquipment()): ?>
            <a href="<?php echo e(route('maintenance.due')); ?>" class="<?php echo e(request()->routeIs('maintenance.*') ? 'is-active' : ''); ?>">
                Maintenance Due
            </a>
            <a href="<?php echo e(route('maintenance-schedules.index')); ?>" class="<?php echo e(request()->routeIs('maintenance-schedules.*') ? 'is-active' : ''); ?>">
                Maintenance Schedule
            </a>
        <?php endif; ?>

        <?php if($user->canManageInventory()): ?>
            <a href="<?php echo e(route('disposal.index')); ?>" class="<?php echo e(request()->routeIs('disposal.*') ? 'is-active' : ''); ?>">
                Disposal Management
            </a>

            <a
                href="<?php echo e(route('movements.index')); ?>"
                class="<?php echo e(request()->routeIs('movements.*') ? 'is-active' : ''); ?>"
            >
                Movement Requests
            </a>

            <div class="nav-section">Reports</div>

            <a href="<?php echo e(route('reports.equipment')); ?>" class="<?php echo e(request()->routeIs('reports.equipment') ? 'is-active' : ''); ?>">
                Equipment Report
            </a>

            <a href="<?php echo e(route('reports.maintenance')); ?>" class="<?php echo e(request()->routeIs('reports.maintenance') ? 'is-active' : ''); ?>">
                Maintenance Report
            </a>

            <a href="<?php echo e(route('reports.disposal')); ?>" class="<?php echo e(request()->routeIs('reports.disposal') ? 'is-active' : ''); ?>">
                Disposal Report
            </a>
        <?php endif; ?>

        <?php if($user->isAdministrator()): ?>
            <div class="nav-section">Administration</div>

            <a href="<?php echo e(route('users.index')); ?>" class="<?php echo e(request()->routeIs('users.*') ? 'is-active' : ''); ?>">
                Users
            </a>

            <a href="<?php echo e(route('audit.index')); ?>" class="<?php echo e(request()->routeIs('audit.*') ? 'is-active' : ''); ?>">
                Audit Logs
            </a>
        <?php endif; ?>
    </nav>

</aside>
<?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/partials/nav.blade.php ENDPATH**/ ?>