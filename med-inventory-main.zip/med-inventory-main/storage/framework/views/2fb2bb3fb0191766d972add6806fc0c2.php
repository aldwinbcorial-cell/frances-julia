<?php $__env->startSection('title', 'Maintenance Due'); ?>
<?php $__env->startSection('page-title', 'Maintenance Due'); ?>
<?php $__env->startSection('page-subtitle', 'Equipment overdue or scheduled for maintenance within the next 30 days'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $overdueCount = $equipment->getCollection()->filter(fn ($item) => $item->nextMaintenanceOn()?->isPast())->count();
    $dueSoonCount = $equipment->getCollection()->filter(function ($item) {
        $date = $item->nextMaintenanceOn();
        return $date && ! $date->isPast();
    })->count();
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-title">Overdue (this page)</div>
        <div class="stat-number"><?php echo e($overdueCount); ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-title">Due Within 30 Days (this page)</div>
        <div class="stat-number"><?php echo e($dueSoonCount); ?></div>
    </div>
</div>

<div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Code</th>
                <th>Equipment</th>
                <th>Department</th>
                <th>Location</th>
                <th>Status</th>
                <th>Next Maintenance</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $equipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $nextDate = $item->nextMaintenanceOn(); ?>
                <tr>
                    <td><?php echo e($item->equipment_code); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->department?->name ?? 'Unassigned'); ?></td>
                    <td><?php echo e($item->location?->name ?? 'Unassigned'); ?></td>
                    <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['value' => $item->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                    <td>
                        <?php if($nextDate?->isPast()): ?>
                            <span class="text-overdue">Overdue: <?php echo e($nextDate->format('M d, Y')); ?></span>
                        <?php else: ?>
                            <span class="text-due-soon">Due: <?php echo e($nextDate?->format('M d, Y')); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('equipment.show', $item)); ?>" class="btn btn-secondary">View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="empty-state">No equipment is overdue or due within the next 30 days.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php echo e($equipment->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/maintenance/due.blade.php ENDPATH**/ ?>