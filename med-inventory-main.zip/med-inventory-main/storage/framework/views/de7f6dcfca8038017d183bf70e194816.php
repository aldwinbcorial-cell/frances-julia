<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> — Medical Equipment Inventory</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="app-body">
<div class="app-shell">
    <input type="checkbox" id="nav-toggle" class="nav-toggle">

    <?php echo $__env->make('partials.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <label for="nav-toggle" class="sidebar-overlay" aria-label="Close navigation"></label>

    <div class="app-main">
        <div class="app-topbar">
            <div class="app-heading-group">
                <label for="nav-toggle" class="nav-toggle-label" aria-label="Open navigation" title="Menu">
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </label>
                <div>
                    <h1><?php echo $__env->yieldContent('page-title'); ?></h1>
                    <?php if (! empty(trim($__env->yieldContent('page-subtitle')))): ?>
                        <p class="page-subtitle"><?php echo $__env->yieldContent('page-subtitle'); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="page-actions">
                <?php echo $__env->yieldContent('page-actions'); ?>
            <?php if(auth()->guard()->check()): ?>
                <?php
                    $unreadCount = auth()
                        ->user()
                        ->unreadNotifications()
                        ->count();
                ?>

                <a
                    href="<?php echo e(route('notifications.index')); ?>"
                    class="notification-button"
                    title="Notifications"
                    aria-label="Notifications"
                >
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M18 8.5a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M10 21h4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                    </svg>

                    <?php if($unreadCount > 0): ?>
                        <span class="notification-count">
                            <?php echo e($unreadCount > 99 ? '99+' : $unreadCount); ?>

                        </span>
                    <?php endif; ?>
                </a>

                <details class="header-user-menu">
                    <summary class="header-user-toggle" aria-label="Open account menu" title="Account">
                        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                            <circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.8"/>
                            <path d="M5 20a7 7 0 0 1 14 0" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                        </svg>
                    </summary>
                    <div class="header-user-dropdown">
                        <div class="header-user-dropdown-name"><?php echo e(auth()->user()->name); ?></div>
                        <div class="header-user-dropdown-role"><?php echo e(auth()->user()->role); ?></div>
                        <form action="<?php echo e(route('logout')); ?>" method="POST" class="header-logout-form">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="header-logout-button">Log out</button>
                        </form>
                    </div>
                </details>
            <?php endif; ?>
            </div>
        </div>

        <div class="app-content">
            <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>
<?php if(session('login_success')): ?>
    <div
        id="login-success-alert"
        data-title="Log In Successfully"
        data-message="Welcome back to MIMS."
        hidden
    ></div>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
<?php endif; ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/layouts/app.blade.php ENDPATH**/ ?>