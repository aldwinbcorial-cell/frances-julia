<?php $__env->startSection('title', 'Audit Logs'); ?>
<?php $__env->startSection('page-title', 'Audit Logs'); ?>
<?php $__env->startSection('page-subtitle', 'Track important actions performed within the system'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <form action="<?php echo e(route('audit.index')); ?>" method="GET">
        <div class="filter-grid">
            <div class="form-group">
                <label for="action">Action</label>
                <select id="action" name="action">
                    <option value="">All Actions</option>
                    <?php $__currentLoopData = ['CREATE', 'UPDATE', 'DELETE', 'ARCHIVE', 'RESTORE', 'MOVE', 'MAINTENANCE', 'DISPOSAL']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($action); ?>" <?php if(request('action') === $action): echo 'selected'; endif; ?>><?php echo e($action); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="table_name">Table</label>
                <select id="table_name" name="table_name">
                    <option value="">All Tables</option>
                    <?php $__currentLoopData = ['equipment', 'equipment_movements', 'maintenance_records', 'disposal_records']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($table); ?>" <?php if(request('table_name') === $table): echo 'selected'; endif; ?>><?php echo e($table); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="filter-actions">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="<?php echo e(route('audit.index')); ?>" class="btn btn-secondary">Reset</a>
        </div>
    </form>
</div>

<div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Date / Time</th>
                <th>User</th>
                <th>Action</th>
                <th>Table</th>
                <th>Record ID</th>
                <th>Description</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($log->created_at?->format('M d, Y h:i A')); ?></td>
                    <td><?php echo e($log->user?->name ?? 'System / Unknown'); ?></td>
                    <td><?php echo e($log->action); ?></td>
                    <td><?php echo e($log->table_name); ?></td>
                    <td><?php echo e($log->record_id ?? 'N/A'); ?></td>
                    <td><?php echo e($log->description ?? 'N/A'); ?></td>
                    <td><a href="<?php echo e(route('audit.show', $log)); ?>" class="btn btn-secondary">View</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="empty-state">No audit logs found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php echo e($logs->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/audit/index.blade.php ENDPATH**/ ?>