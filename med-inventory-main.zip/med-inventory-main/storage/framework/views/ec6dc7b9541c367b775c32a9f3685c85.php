<?php $__env->startSection('title', 'Archived Equipment'); ?>
<?php $__env->startSection('page-title', 'Archived Equipment'); ?>
<?php $__env->startSection('page-subtitle', 'Equipment removed from the active inventory'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <form method="GET" action="<?php echo e(route('equipment.archived')); ?>">
        <div class="scan-row">
            <input
                type="text"
                name="search"
                value="<?php echo e(request('search')); ?>"
                placeholder="Search archived equipment..."
            >
            <button type="submit" class="btn btn-primary">Search</button>
            <a href="<?php echo e(route('equipment.archived')); ?>" class="btn btn-secondary">Reset</a>
        </div>
    </form>
</div>

<div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Category</th>
                <th>Department</th>
                <th>Location</th>
                <th>Archived At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $equipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($item->equipment_code); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->category?->name ?? 'N/A'); ?></td>
                    <td><?php echo e($item->department?->name ?? 'Unassigned'); ?></td>
                    <td><?php echo e($item->location?->name ?? 'Unassigned'); ?></td>
                    <td><?php echo e($item->archived_at?->format('M d, Y h:i A')); ?></td>
                    <td>
                        <div class="table-actions">
                            <a href="<?php echo e(route('equipment.show', $item)); ?>" class="btn btn-secondary">View</a>
                            <form
                                action="<?php echo e(route('equipment.restore', $item)); ?>"
                                method="POST"
                                onsubmit="return confirm('Restore this equipment?');"
                            >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button type="submit" class="btn btn-success">Restore</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="empty-state">No archived equipment found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php echo e($equipment->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/equipment/archived.blade.php ENDPATH**/ ?>