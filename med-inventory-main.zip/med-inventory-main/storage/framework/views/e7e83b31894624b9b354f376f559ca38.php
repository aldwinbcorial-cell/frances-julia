<?php $__env->startSection('title', 'Movement Requests'); ?>
<?php $__env->startSection('page-title', 'Movement Requests'); ?>
<?php $__env->startSection('page-subtitle', 'Approve or reject pending equipment transfers'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h2>Pending Transfer Requests</h2>
    </div>

    <?php if($movements->count()): ?>
        <table>
            <thead>
                <tr>
                    <th>Equipment</th>
                    <th>Requested By</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Reason</th>
                    <th>Requested</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('equipment.show', $movement->equipment)); ?>">
                                <?php echo e($movement->equipment?->equipment_code); ?>

                                -
                                <?php echo e($movement->equipment?->name); ?>

                            </a>
                        </td>

                        <td>
                            <?php echo e($movement->movedBy?->name ?? 'Unknown'); ?>

                        </td>

                        <td>
                            <?php echo e($movement->fromDepartment?->name ?? 'Unassigned'); ?>

                            /
                            <?php echo e($movement->fromLocation?->name ?? 'Unassigned'); ?>

                        </td>

                        <td>
                            <?php echo e($movement->toDepartment?->name ?? 'Unassigned'); ?>

                            /
                            <?php echo e($movement->toLocation?->name ?? 'Unassigned'); ?>

                        </td>

                        <td>
                            <?php echo e($movement->reason); ?>


                            <?php if($movement->remarks): ?>
                                <br>
                                <small><?php echo e($movement->remarks); ?></small>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php echo e($movement->created_at?->format('M d, Y h:i A')); ?>

                        </td>

                        <td>
                            <div class="table-actions">

                                <form
                                    action="<?php echo e(route('movements.approve', $movement)); ?>"
                                    method="POST"
                                    onsubmit="return confirm('Approve this movement request?');"
                                >
                                    <?php echo csrf_field(); ?>

                                    <button
                                        type="submit"
                                        class="btn btn-success"
                                    >
                                        Approve
                                    </button>
                                </form>

                                <form
                                    action="<?php echo e(route('movements.reject', $movement)); ?>"
                                    method="POST"
                                    onsubmit="return confirm('Reject this movement request?');"
                                >
                                    <?php echo csrf_field(); ?>

                                    <input
                                        type="text"
                                        name="rejection_reason"
                                        placeholder="Reason for rejection"
                                        required
                                    >

                                    <button
                                        type="submit"
                                        class="btn btn-danger"
                                    >
                                        Reject
                                    </button>
                                </form>

                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($movements->links('pagination.app')); ?>

    <?php else: ?>
        <div class="empty-state">
            There are currently no pending movement requests.
        </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/movements/index.blade.php ENDPATH**/ ?>