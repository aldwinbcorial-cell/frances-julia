<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<main class="login-shell">
    <section class="login-showcase" aria-label="Medical inventory">
        <div class="login-brand">
            <span class="brand-mark" aria-hidden="true">
                <span></span>
            </span>
            <div>
                <strong>mims</strong>
                <small>MEDICAL INVENTORY</small>
            </div>
        </div>

        <div class="showcase-copy">
            <p class="showcase-kicker">ILOCOS TRAINING AND REGIONAL MEDICAL CENTER</p>
            <h1>Managing<br>Inventory<br>with Care and<br>Integrity.</h1>
            <p class="showcase-description">Keep medical assets, assignments, and<br>maintenance in one clear view.</p>
        </div>

        <p class="showcase-footer">MEDICAL INVENTORY MANAGEMENT SYSTEM <span>•</span> 2026</p>
    </section>

    <section class="login-panel" aria-label="Sign in">
        <div class="login-card">
            <p class="welcome-label">WELCOME BACK</p>
            <h2>Sign in to MIMS</h2>
            <p class="login-description">Use your staff account to continue to the inventory workspace.</p>

            <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php if($errors->any()): ?>
                <div class="login-error" role="alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('login.submit')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-stack">
                    <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="field-error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="password-field">
                            <input type="password" id="password" name="password" required>
                            <button type="button" class="password-toggle" aria-label="Show password" aria-controls="password" aria-pressed="false">
                                <svg class="eye-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                                    <path d="M2.5 12s3.5-5.5 9.5-5.5 9.5 5.5 9.5 5.5-3.5 5.5-9.5 5.5S2.5 12 2.5 12Z" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
                                    <circle cx="12" cy="12" r="2.8" stroke="currentColor" stroke-width="1.7"/>
                                </svg>
                                <svg class="eye-off-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                                    <path d="M3 3l18 18M10.6 6.7c.45-.13.92-.2 1.4-.2 6 0 9.5 5.5 9.5 5.5a15.7 15.7 0 0 1-3.1 3.45M6.2 8.1A15.1 15.1 0 0 0 2.5 12s3.5 5.5 9.5 5.5c1.2 0 2.3-.22 3.3-.58M9.88 9.88a3 3 0 0 0 4.24 4.24" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                <button type="submit" class="login-submit">
                    <span>Sign in</span>
                    <span class="submit-arrow" aria-hidden="true">→</span>
                </button>
            </form>

        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/auth/login.blade.php ENDPATH**/ ?>