

<?php $__env->startSection('title', 'Edit Maintenance Schedule'); ?>
<?php $__env->startSection('page-title', 'Edit Maintenance Schedule'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <form action="<?php echo e(route('maintenance-schedules.update', $maintenanceSchedule)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <?php echo $__env->make('maintenance-schedules._form', [
            'maintenanceSchedule' => $maintenanceSchedule,
            'submitLabel' => 'Update Schedule',
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/maintenance-schedules/edit.blade.php ENDPATH**/ ?>