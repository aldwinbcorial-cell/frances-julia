<?php
    $schedule = $maintenanceSchedule ?? null;
?>

<div class="panel-note">
    <?php if($schedule): ?>
        Mark this schedule completed after service. Add a maintenance record from the equipment page to capture results and cost.
    <?php else: ?>
        Scheduling maintenance does not change the equipment's current status or maintenance history.
    <?php endif; ?>
</div>

<div class="form-grid">
    <?php if($schedule): ?>
        <div class="panel-note full-width">
            <strong>Equipment:</strong>
            <?php echo e($schedule->equipment->equipment_code); ?> - <?php echo e($schedule->equipment->name); ?>

        </div>
    <?php else: ?>
        <div class="form-group full-width">
            <label for="equipment_id">Equipment *</label>
            <select id="equipment_id" name="equipment_id" required>
                <option value="">Select Equipment</option>
                <?php $__currentLoopData = $equipmentOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($equipment->id); ?>" <?php if((string) old('equipment_id', $selectedEquipmentId) === (string) $equipment->id): echo 'selected'; endif; ?>>
                        <?php echo e($equipment->equipment_code); ?> - <?php echo e($equipment->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['equipment_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="field-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    <?php endif; ?>

    <div class="form-group">
        <label for="maintenance_type">Maintenance Type *</label>
        <select id="maintenance_type" name="maintenance_type" required>
            <option value="">Select Type</option>
            <?php $__currentLoopData = \App\Models\MaintenanceRecord::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($type); ?>" <?php if(old('maintenance_type', $schedule?->maintenance_type) === $type): echo 'selected'; endif; ?>>
                    <?php echo e($type); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['maintenance_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="field-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="scheduled_date">Scheduled Date *</label>
        <input
            type="date"
            id="scheduled_date"
            name="scheduled_date"
            value="<?php echo e(old('scheduled_date', $schedule?->scheduled_date?->format('Y-m-d'))); ?>"
            <?php if(! $schedule): ?> min="<?php echo e(now()->toDateString()); ?>" <?php endif; ?>
            required
        >
        <?php $__errorArgs = ['scheduled_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="field-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="assigned_to">Assigned To</label>
        <input
            type="text"
            id="assigned_to"
            name="assigned_to"
            value="<?php echo e(old('assigned_to', $schedule?->assigned_to)); ?>"
            placeholder="Technician or service provider"
        >
        <?php $__errorArgs = ['assigned_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="field-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <?php if($schedule): ?>
        <div class="form-group">
            <label for="status">Status *</label>
            <select id="status" name="status" required>
                <?php $__currentLoopData = \App\Models\MaintenanceSchedule::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if(old('status', $schedule->status) === $status): echo 'selected'; endif; ?>>
                        <?php echo e($status); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="field-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    <?php endif; ?>

    <div class="form-group full-width">
        <label for="description">Description *</label>
        <textarea id="description" name="description" required><?php echo e(old('description', $schedule?->description)); ?></textarea>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="field-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group full-width">
        <label for="remarks">Remarks</label>
        <textarea id="remarks" name="remarks"><?php echo e(old('remarks', $schedule?->remarks)); ?></textarea>
        <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="field-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-actions">
    <button type="submit" class="btn btn-primary"><?php echo e($submitLabel); ?></button>
    <a href="<?php echo e(route('maintenance-schedules.index')); ?>" class="btn btn-secondary">Cancel</a>
</div>
<?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/maintenance-schedules/_form.blade.php ENDPATH**/ ?>