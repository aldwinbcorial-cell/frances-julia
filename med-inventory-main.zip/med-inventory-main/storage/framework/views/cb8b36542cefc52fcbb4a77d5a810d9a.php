

<?php $__env->startSection('title', 'Schedule Maintenance'); ?>
<?php $__env->startSection('page-title', 'Schedule Maintenance'); ?>
<?php $__env->startSection('page-subtitle', 'Plan a maintenance visit for equipment'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <form action="<?php echo e(route('maintenance-schedules.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('maintenance-schedules._form', [
            'equipmentOptions' => $equipmentOptions,
            'selectedEquipmentId' => $selectedEquipmentId,
            'submitLabel' => 'Save Schedule',
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/maintenance-schedules/create.blade.php ENDPATH**/ ?>