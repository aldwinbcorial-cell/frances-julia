<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>
<?php $__env->startSection('page-subtitle', 'Operational overview for the current inventory'); ?>

<?php $__env->startSection('content'); ?>
<?php $user = auth()->user(); ?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-heading">
            <div class="stat-title">Total Active Equipment</div>
            <span class="stat-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none">
                    <path d="M8 3.75h8a2 2 0 0 1 2 2v14.5H6V5.75a2 2 0 0 1 2-2Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
                    <path d="M9 3.75v-1h6v1M12 8v7M8.5 11.5h7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                </svg>
            </span>
        </div>
        <div class="stat-number"><a href="<?php echo e(route('equipment.index')); ?>"><?php echo e($totalEquipment); ?></a></div>
    </div>
    <div class="stat-card">
        <div class="stat-heading">
            <div class="stat-title">Working</div>
            <span class="stat-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.8"/>
                    <path d="m8 12.2 2.6 2.6 5.5-5.7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
        </div>
        <div class="stat-number"><a href="<?php echo e(route('equipment.index', ['status' => 'Working'])); ?>"><?php echo e($workingEquipment); ?></a></div>
    </div>
    <div class="stat-card">
        <div class="stat-heading">
            <div class="stat-title">Needs Attention</div>
            <span class="stat-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none">
                    <path d="M10.3 4.7a2 2 0 0 1 3.4 0l7 12.2a2 2 0 0 1-1.7 3H5a2 2 0 0 1-1.7-3l7-12.2Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
                    <path d="M12 9v4.5M12 17h.01" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                </svg>
            </span>
        </div>
        <div class="stat-number"><?php echo e($needsAttention); ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-heading">
            <div class="stat-title">Maintenance Due</div>
            <span class="stat-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none">
                    <rect x="4" y="5.5" width="16" height="15" rx="2" stroke="currentColor" stroke-width="1.8"/>
                    <path d="M8 3.5v4M16 3.5v4M4 10h16M8 14h2M14 14h2M8 17h2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                </svg>
            </span>
        </div>
        <div class="stat-number">
            <?php if($user->canMaintainEquipment()): ?>
                <a href="<?php echo e(route('maintenance.due')); ?>"><?php echo e($maintenanceDue); ?></a>
            <?php else: ?>
                <?php echo e($maintenanceDue); ?>

            <?php endif; ?>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-heading">
            <div class="stat-title">For Disposal</div>
            <span class="stat-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none">
                    <path d="M4.5 7h15M9 7V4.5h6V7m3.5 0-.8 12.2a2 2 0 0 1-2 1.8h-7.4a2 2 0 0 1-2-1.8L5.5 7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M10 10.5v6M14 10.5v6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                </svg>
            </span>
        </div>
        <div class="stat-number">
            <?php if($user->canManageInventory()): ?>
                <a href="<?php echo e(route('disposal.index')); ?>"><?php echo e($forDisposal); ?></a>
            <?php else: ?>
                <?php echo e($forDisposal); ?>

            <?php endif; ?>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-heading">
            <div class="stat-title">Archived</div>
            <span class="stat-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none">
                    <path d="M4 7.5h16v13H4v-13ZM3 3.5h18v4H3v-4Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
                    <path d="M9 11.5h6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                </svg>
            </span>
        </div>
        <div class="stat-number">
            <?php if($user->canManageInventory()): ?>
                <a href="<?php echo e(route('equipment.archived')); ?>"><?php echo e($archived); ?></a>
            <?php else: ?>
                <?php echo e($archived); ?>

            <?php endif; ?>
        </div>
    </div>
</div>

<div class="card">
    <h2>Quick Links</h2>
    <div class="quick-links">
        <a href="<?php echo e(route('equipment.index')); ?>" class="btn btn-secondary">Browse Equipment</a>

        <?php if($user->canManageInventory()): ?>
            <a href="<?php echo e(route('equipment.create')); ?>" class="btn btn-primary">Add Equipment</a>
            <a href="<?php echo e(route('disposal.index')); ?>" class="btn btn-secondary">Disposal</a>
            <a href="<?php echo e(route('reports.equipment')); ?>" class="btn btn-secondary">Equipment Report</a>
        <?php endif; ?>

        <?php if($user->canMaintainEquipment()): ?>
            <a href="<?php echo e(route('maintenance.due')); ?>" class="btn btn-secondary">Maintenance Due</a>
        <?php endif; ?>

        <?php if($user->isAdministrator()): ?>
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Users</a>
            <a href="<?php echo e(route('audit.index')); ?>" class="btn btn-secondary">Audit Logs</a>
        <?php endif; ?>
    </div>
</div>

<?php if($user->canMaintainEquipment()): ?>
    <div class="card">
        <div class="card-header">
            <h2>Upcoming / Overdue Maintenance</h2>
            <a href="<?php echo e(route('maintenance.due')); ?>" class="btn btn-secondary">View all</a>
        </div>

        <div class="table-wrap table-wrap-borderless">
            <table>
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Equipment</th>
                        <th>Assignment</th>
                        <th>Next Maintenance</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $upcomingMaintenance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $nextDate = $item->nextMaintenanceOn(); ?>
                        <tr>
                            <td><?php echo e($item->equipment_code); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->department?->name ?? 'Unassigned'); ?> / <?php echo e($item->location?->name ?? 'Unassigned'); ?></td>
                            <td>
                                <?php if($nextDate?->isPast()): ?>
                                    <span class="text-overdue">Overdue: <?php echo e($nextDate->format('M d, Y')); ?></span>
                                <?php else: ?>
                                    <span class="text-due-soon"><?php echo e($nextDate?->format('M d, Y')); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><a href="<?php echo e(route('equipment.show', $item)); ?>" class="btn btn-secondary">View</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="empty-state">No maintenance is overdue or due within 30 days.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<?php if($user->isAdministrator()): ?>
    <div class="card">
        <div class="card-header">
            <h2>Recent Activity</h2>
            <a href="<?php echo e(route('audit.index')); ?>" class="btn btn-secondary">Audit logs</a>
        </div>

        <div class="table-wrap table-wrap-borderless">
            <table>
                <thead>
                    <tr>
                        <th>Date / Time</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentAuditLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($log->created_at?->format('M d, Y h:i A')); ?></td>
                            <td><?php echo e($log->user?->name ?? 'System / Unknown'); ?></td>
                            <td><?php echo e($log->action); ?></td>
                            <td><?php echo e($log->description ?? 'N/A'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="empty-state">No recent activity found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/dashboard/index.blade.php ENDPATH**/ ?>