<?php $__env->startSection('title', 'Disposal Management'); ?>
<?php $__env->startSection('page-title', 'Disposal Management'); ?>
<?php $__env->startSection('page-subtitle', 'Equipment awaiting disposal and completed disposal records'); ?>

<?php $__env->startSection('content'); ?>
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-title">For Disposal</div>
        <div class="stat-number"><?php echo e($forDisposal->total()); ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-title">Disposed</div>
        <div class="stat-number"><?php echo e($disposed->total()); ?></div>
    </div>
</div>

<div class="card">
    <h2>Equipment For Disposal</h2>
    <div class="table-wrap table-wrap-borderless">
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Equipment</th>
                    <th>Department</th>
                    <th>Location</th>
                    <th>Condition</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $forDisposal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($item->equipment_code); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->department?->name ?? 'Unassigned'); ?></td>
                        <td><?php echo e($item->location?->name ?? 'Unassigned'); ?></td>
                        <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['value' => $item->condition_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->condition_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                        <td>
                            <div class="table-actions">
                                <a href="<?php echo e(route('equipment.show', $item)); ?>" class="btn btn-secondary">View</a>
                                <a href="<?php echo e(route('disposal.create', $item)); ?>" class="btn btn-danger">Dispose</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="empty-state">No equipment is currently marked for disposal.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php echo e($forDisposal->links()); ?>

</div>

<div class="card">
    <h2>Disposed Equipment</h2>
    <div class="table-wrap table-wrap-borderless">
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Equipment</th>
                    <th>Disposal Date</th>
                    <th>Method</th>
                    <th>Reference</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $disposed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($item->equipment_code); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->disposalRecord?->disposal_date?->format('M d, Y') ?? 'N/A'); ?></td>
                        <td><?php echo e($item->disposalRecord?->disposal_method ?? 'N/A'); ?></td>
                        <td><?php echo e($item->disposalRecord?->disposal_reference ?? 'N/A'); ?></td>
                        <td>
                            <a href="<?php echo e(route('equipment.show', $item)); ?>" class="btn btn-secondary">View</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="empty-state">No disposed equipment records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php echo e($disposed->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/disposal/index.blade.php ENDPATH**/ ?>