<?php $__env->startSection('title', 'Import Equipment'); ?>
<?php $__env->startSection('page-title', 'Import Equipment'); ?>
<?php $__env->startSection(
    'page-subtitle',
    'Bulk import equipment records from Excel or CSV'
); ?>

<?php $__env->startSection('content'); ?>

<div class="card">

    <h2>Upload Spreadsheet</h2>

    <div class="panel-note">
        <strong>Supported formats:</strong>
        XLSX, XLS, CSV

        <br><br>

        <strong>Required columns:</strong>

        <code>equipment_code</code>,
        <code>name</code>,
        <code>category</code>

        <br><br>

        Existing equipment codes and barcodes will not
        be imported again.
    </div>

    <form
        action="<?php echo e(route('equipment.import.store')); ?>"
        method="POST"
        enctype="multipart/form-data"
    >
        <?php echo csrf_field(); ?>

        <div class="form-stack">

            <div class="form-group">

                <label for="file">
                    Excel / CSV File *
                </label>

                <input
                    type="file"
                    id="file"
                    name="file"
                    accept=".xlsx,.xls,.csv"
                    required
                >

                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="field-error">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

        </div>

        <div class="form-actions">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Import Equipment
            </button>

            <a
                href="<?php echo e(route('equipment.index')); ?>"
                class="btn btn-secondary"
            >
                Cancel
            </a>

        </div>

    </form>

</div>


<div class="card">

    <h2>Spreadsheet Format</h2>

    <p>
        Use the following column names in the first row
        of your spreadsheet:
    </p>

    <pre>equipment_code
barcode
name
category
brand
model
serial_number
property_number
purchase_date
purchase_price
supplier
warranty_expiry
status
condition_status
lifecycle_status
department
location
remarks</pre>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/equipment/import.blade.php ENDPATH**/ ?>