<?php $__env->startSection('title', 'Locations'); ?>
<?php $__env->startSection('page-title', 'Locations'); ?>

<?php $__env->startSection('page-actions'); ?>
    <?php if(auth()->user()->canManageInventory()): ?>
        <a href="<?php echo e(route('locations.create')); ?>" class="btn btn-primary">Add Location</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Department</th>
                <th>Description</th>
                <th>Equipment</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($location->name); ?></td>
                    <td><?php echo e($location->department?->name ?? 'N/A'); ?></td>
                    <td><?php echo e($location->description ?? 'N/A'); ?></td>
                    <td><?php echo e($location->equipment_count); ?></td>
                    <td>
                        <div class="table-actions">
                            <a href="<?php echo e(route('locations.show', $location)); ?>" class="btn btn-secondary">View</a>
                            <?php if(auth()->user()->canManageInventory()): ?>
                                <a href="<?php echo e(route('locations.edit', $location)); ?>" class="btn btn-secondary">Edit</a>
                                <?php if($location->equipment_count === 0): ?>
                                    <form action="<?php echo e(route('locations.destroy', $location)); ?>" method="POST" onsubmit="return confirm('Delete this location?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="empty-state">No locations found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php echo e($locations->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\med-inventory-main\resources\views/locations/index.blade.php ENDPATH**/ ?>