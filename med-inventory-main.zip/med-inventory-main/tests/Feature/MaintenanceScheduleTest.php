<?php

namespace Tests\Feature;

use App\Models\Equipment;
use App\Models\MaintenanceSchedule;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class MaintenanceScheduleTest extends TestCase
{
    use RefreshDatabase;

    public function test_maintenance_staff_can_schedule_equipment_without_changing_its_status(): void
    {
        $user = User::factory()->create(['role' => User::ROLE_MAINTENANCE_STAFF]);
        $equipment = Equipment::factory()->create();

        $response = $this->actingAs($user)->post(route('maintenance-schedules.store'), [
            'equipment_id' => $equipment->id,
            'maintenance_type' => 'Preventive Maintenance',
            'scheduled_date' => now()->addWeek()->toDateString(),
            'assigned_to' => 'Service Team',
            'description' => 'Annual safety inspection',
        ]);

        $response->assertRedirect(route('maintenance-schedules.index'));
        $this->assertDatabaseHas('maintenance_schedules', [
            'equipment_id' => $equipment->id,
            'maintenance_type' => 'Preventive Maintenance',
            'status' => 'Scheduled',
        ]);
        $this->assertSame('Working', $equipment->fresh()->status);
    }

    public function test_schedule_date_cannot_be_in_the_past(): void
    {
        $user = User::factory()->create(['role' => User::ROLE_MAINTENANCE_STAFF]);
        $equipment = Equipment::factory()->create();

        $response = $this->actingAs($user)->from(route('maintenance-schedules.create'))->post(
            route('maintenance-schedules.store'),
            [
                'equipment_id' => $equipment->id,
                'maintenance_type' => 'Inspection',
                'scheduled_date' => now()->subDay()->toDateString(),
                'description' => 'Inspect equipment safety',
            ]
        );

        $response->assertRedirect(route('maintenance-schedules.create'));
        $response->assertSessionHasErrors('scheduled_date');
        $this->assertDatabaseCount('maintenance_schedules', 0);
    }

    public function test_disposed_equipment_cannot_be_scheduled(): void
    {
        $user = User::factory()->create(['role' => User::ROLE_MAINTENANCE_STAFF]);
        $equipment = Equipment::factory()->create(['lifecycle_status' => 'Disposed']);

        $response = $this->actingAs($user)->from(route('maintenance-schedules.create'))->post(
            route('maintenance-schedules.store'),
            [
                'equipment_id' => $equipment->id,
                'maintenance_type' => 'Inspection',
                'scheduled_date' => now()->addWeek()->toDateString(),
                'description' => 'Inspect equipment safety',
            ]
        );

        $response->assertRedirect(route('maintenance-schedules.create'));
        $response->assertSessionHas('error');
        $this->assertDatabaseCount('maintenance_schedules', 0);
    }

    public function test_viewer_cannot_access_maintenance_schedules(): void
    {
        $user = User::factory()->create(['role' => User::ROLE_VIEWER]);

        $response = $this->actingAs($user)->get(route('maintenance-schedules.index'));

        $response->assertForbidden();
    }

    public function test_schedule_is_visible_on_the_schedule_list_and_equipment_page(): void
    {
        $user = User::factory()->create(['role' => User::ROLE_MAINTENANCE_STAFF]);
        $schedule = MaintenanceSchedule::factory()->create([
            'description' => 'Annual safety inspection',
        ]);

        $this->actingAs($user)
            ->get(route('maintenance-schedules.create', ['equipment_id' => $schedule->equipment_id]))
            ->assertOk()
            ->assertSee('Schedule Maintenance');

        $this->get(route('maintenance-schedules.edit', $schedule))
            ->assertOk()
            ->assertSee('Status');

        $this->get(route('maintenance-schedules.index'))
            ->assertOk()
            ->assertSee('Annual safety inspection')
            ->assertSee($schedule->equipment->equipment_code);

        $this->get(route('equipment.show', $schedule->equipment))
            ->assertOk()
            ->assertSee('Maintenance Schedule')
            ->assertSee('Annual safety inspection');
    }

    public function test_schedule_can_be_marked_completed(): void
    {
        $user = User::factory()->create(['role' => User::ROLE_MAINTENANCE_STAFF]);
        $schedule = MaintenanceSchedule::factory()->create();

        $response = $this->actingAs($user)->put(route('maintenance-schedules.update', $schedule), [
            'maintenance_type' => $schedule->maintenance_type,
            'scheduled_date' => $schedule->scheduled_date->toDateString(),
            'assigned_to' => $schedule->assigned_to,
            'description' => $schedule->description,
            'status' => 'Completed',
        ]);

        $response->assertRedirect(route('maintenance-schedules.index'));
        $this->assertDatabaseHas('maintenance_schedules', [
            'id' => $schedule->id,
            'status' => 'Completed',
        ]);
    }
}
