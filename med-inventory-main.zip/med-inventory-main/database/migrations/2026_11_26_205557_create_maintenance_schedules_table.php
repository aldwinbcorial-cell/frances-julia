<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('maintenance_schedules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('equipment_id')
                ->constrained('equipment')
                ->restrictOnDelete();
            $table->string('maintenance_type');
            $table->date('scheduled_date');
            $table->string('assigned_to')->nullable();
            $table->text('description');
            $table->string('status')->default('Scheduled');
            $table->text('remarks')->nullable();
            $table->timestamps();

            $table->index(['status', 'scheduled_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('maintenance_schedules');
    }
};
