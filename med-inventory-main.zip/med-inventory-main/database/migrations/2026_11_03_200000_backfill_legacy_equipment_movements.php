<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // Old movement records predate the approval workflow. Avoid changing newer requests.
        DB::table('equipment_movements')
            ->where('approval_status', 'Pending')
            ->where('created_at', '<', '2026-11-02 20:27:41')
            ->update(['approval_status' => 'Approved']);
    }

    public function down(): void
    {
        // Historical information cannot safely be reverted to Pending.
    }
};
