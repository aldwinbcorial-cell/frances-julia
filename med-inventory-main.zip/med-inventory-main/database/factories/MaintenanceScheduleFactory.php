<?php

namespace Database\Factories;

use App\Models\Equipment;
use App\Models\MaintenanceRecord;
use App\Models\MaintenanceSchedule;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<MaintenanceSchedule>
 */
class MaintenanceScheduleFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'equipment_id' => Equipment::factory(),
            'maintenance_type' => fake()->randomElement(MaintenanceRecord::TYPES),
            'scheduled_date' => fake()->dateTimeBetween('today', '+1 year')->format('Y-m-d'),
            'assigned_to' => fake()->name(),
            'description' => fake()->sentence(),
            'status' => 'Scheduled',
            'remarks' => fake()->optional()->sentence(),
        ];
    }
}
