<?php

namespace Database\Factories;

use App\Models\Equipment;
use App\Models\EquipmentCategory;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Equipment>
 */
class EquipmentFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'equipment_code' => 'EQ-'.fake()->unique()->numerify('######'),
            'name' => fake()->words(2, true),
            'category_id' => EquipmentCategory::factory(),
            'status' => 'Working',
            'condition_status' => 'Good',
            'lifecycle_status' => 'Active',
        ];
    }
}
